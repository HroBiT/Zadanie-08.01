﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie0
{
    public abstract class Osoba
    {
        public string Imie;
        public string Nazwisko;
    }
}
