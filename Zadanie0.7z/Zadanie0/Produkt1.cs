﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie0
{
    public interface Produkt1
    {
        void WyświetlInfo();
        decimal AktualnaCena();
        int DostępnaIlosc();
    }
}
